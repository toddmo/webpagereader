/* Namespace */
var WebPageReader = WebPageReader || {
  /*  Web Page Reader 0.4
      try to read minimal data to get current, next or previous sentence 
  */
  version: 0.4
};

WebPageReader.UI = WebPageReader.UI || {};


/* Namespace */
var WebPageReader = WebPageReader || {
  /*  Web Page Reader 0.5.5
      try to read minimal data to get current, next or previous sentence 
  */
  version: '0.6.0'
};

WebPageReader.UI = WebPageReader.UI || {};

// var request = new XMLHttpRequest();
// request.open("GET", "../manifest.json", false);
// request.send(null)
// var manifest = JSON.parse(request.responseText).result[0];



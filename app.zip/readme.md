# <span style="color:orange">Web Page Reader - Release Notes</span>

## <span style="color:dodgerblue">Version 0.7.0</span>

### <span style="color:aquamarine">New Features</span>

- <span style="color:limegreen">✓</span> Version 3 manifest
- <span style="color:limegreen">✓</span> Compliant minimum permissions
  - <span style="color:limegreen">✓</span> Mind the new permissions limits
- <span style="color:limegreen">✓</span> ES6 Classes
- <span style="color:limegreen">✓</span> Dark Mode for reader controls
- <span style="color:limegreen">✓</span> Better "sentence" detection
  - <span style="color:limegreen">✓</span> Stand alone block element text is its own "sentence" for reading purposes
- ❌ Better voices, get from Google API
  - <span style="color:limegreen">✓</span> Standard voices were good enough
- <span style="color:limegreen">✓</span> Ability to skip reading sections of code
- <span style="color:limegreen">✓</span> Control over the highlight color
- <span style="color:limegreen">✓</span> Repeat current sentence with <kbd>Enter</kbd> key

### <span style="color:plum">Bug Fixes</span>

- <span style="color:limegreen">✓</span> \w*\.\w* is not a sentence demarkation. Need whitespace after the period.
- <span style="color:limegreen">✓</span> stops speaking randomly in the middle of long sentences
- 🕑 Bug Bash
  - <span style="color:limegreen">✓?</span> continues reading after pause
  - <span style="color:limegreen">✓</span> Voice not initially set
  - <span style="color:limegreen">✓</span> Speech doesn't speak at first
  - <span style="color:limegreen">✓?</span> Uncaught Error: Extension context invalidated.
